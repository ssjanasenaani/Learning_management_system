# Learning Management System (LMS)

A fully functional full-stack Learning Management System built with Node.js, Express, MongoDB, and Vanilla JavaScript. Students can browse courses, enroll, watch YouTube-hosted lessons, and track their learning progress.

## 🎯 Key Features

✅ **Multiple Courses** – Browse 4+ pre-loaded courses with detailed information  
✅ **Enrollment System** – Easy course enrollment with progress tracking  
✅ **Video Learning** – YouTube iframe player for seamless video watching  
✅ **Progress Tracking** – Automatic lesson completion tracking and progress percentage  
✅ **Resume Learning** – Continue from the last watched lesson  
✅ **Create Courses** – Add new courses and lessons on the fly  
✅ **Modern UI** – Beautiful gradient design with smooth animations  
✅ **Responsive Design** – Works on desktop and mobile devices  

## 🛠️ Tech Stack

- **Backend:** Node.js + Express.js
- **Database:** MongoDB with Mongoose ODM
- **Frontend:** Vanilla HTML5, CSS3, JavaScript
- **Video:** YouTube iframe embeds (no local video storage)

## 📦 Installation & Setup

### Prerequisites

- Node.js (LTS) – [Download](https://nodejs.org/)
- MongoDB Community Server – [Download](https://www.mongodb.com/try/download/community)

### Step 1: Install Dependencies

```powershell
cd backend
npm install
```

### Step 2: Start MongoDB Service

```powershell
net start MongoDB
# OR run mongod manually in another terminal
mongod
```

### Step 3: Seed Sample Data

```powershell
npm run seed
```

This creates 4 courses (AI & ML, Java, Python, Data Science) with 6 lessons each.

### Step 4: Launch the Server

```powershell
npm start
```

The server starts on **http://localhost:5000/**

## 🎮 Using the Application

1. **Open** http://localhost:5000/ in your browser
2. **Browse** available courses on the home page
3. **Click "View"** to see full course details
4. **Click "Enroll"** to start learning
5. **Watch lessons** and navigate with Next/Previous buttons
6. **Track progress** – completed lessons show with strikethrough
7. **Resume** – return to any course and continue where you left off
8. **Create** – add new courses using the "Add Course" button

## 📚 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/courses` | List all courses |
| POST | `/api/courses` | Create a new course |
| GET | `/api/courses/:id` | Get course details with lessons |
| POST | `/api/courses/:id/lessons` | Add lesson to course |
| GET | `/api/lessons/:id` | Get lesson details |
| POST | `/api/users` | Create new user |
| POST | `/api/users/:id/enroll` | Enroll user in course |
| GET | `/api/progress?userId=&courseId=` | Get user progress |
| POST | `/api/progress` | Mark lesson as completed |

## 📁 Project Structure

```
Learning_Management_System/
├── backend/
│   ├── models/
│   │   ├── Course.js
│   │   ├── Lesson.js
│   │   ├── Progress.js
│   │   └── User.js
│   ├── routes/
│   │   ├── courses.js
│   │   ├── lessons.js
│   │   ├── progress.js
│   │   └── users.js
│   ├── server.js
│   ├── seed.js
│   ├── dump.js
│   └── package.json
├── frontend/
│   ├── index.html
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── app.js
└── README.md
```

## 🎨 UI/UX Features

- **Modern Gradient Design** – Purple gradient background with smooth transitions
- **Card-based Layout** – Course cards with hover effects and shadows
- **Progress Visualization** – Animated progress bar with percentage
- **Smooth Animations** – Hover effects, transitions, and interactive elements
- **Mobile Responsive** – Adapts to different screen sizes
- **Accessibility** – Clear buttons, readable text, good contrast

## 💾 Data Models

### Course
```javascript
{
  title: String,
  thumbnail: String,
  instructor: String,
  shortDescription: String,
  fullDescription: String,
  learningOutcomes: [String],
  totalLessons: Number,
  duration: String,
  lessons: [ObjectId]
}
```

### Lesson
```javascript
{
  course: ObjectId,
  title: String,
  order: Number,
  videoUrl: String (YouTube embed URL)
}
```

### Progress
```javascript
{
  user: ObjectId,
  course: ObjectId,
  lesson: ObjectId,
  completedAt: Date
}
```

## 🚀 Development

### Run in Watch Mode
```powershell
npm run dev
```

### View Database Contents
```powershell
node dump.js
```

### Helpful Commands
```powershell
# Seed database
npm run seed

# Start server
npm start

# Check MongoDB
mongosh
```

## 📝 Notes

- Videos are **not stored locally** – only YouTube URLs/IDs are saved in the database
- **No authentication** required – a demo user is created on app load
- **MongoDB defaults** to `mongodb://localhost:27017/lms`
- Customize `MONGO_URI` in a `.env` file if needed

## 🔄 Future Enhancements

- User authentication & authorization
- Admin dashboard for course management
- Video upload support (AWS S3 integration)
- Quiz/assignment system
- Discussion forums
- Certificate generation
- Payment integration
- Email notifications

## 📄 License

MIT

