// Enhanced script to populate sample courses and lessons with better data
const mongoose = require('mongoose');
require('dotenv').config();
const Course = require('./models/Course');
const Lesson = require('./models/Lesson');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/lms';

async function run() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✓ Connected to MongoDB');

    await Course.deleteMany({});
    await Lesson.deleteMany({});
    console.log('✓ Cleared existing data');

    const courseData = [
      {
        title: 'AI & Machine Learning',
        thumbnail: 'https://via.placeholder.com/280x160?text=AI+%26+ML',
        instructor: 'Dr. Ankit Sharma',
        shortDescription: 'Advanced concepts in artificial intelligence and machine learning.',
        fullDescription: 'Deep dive into AI algorithms, neural networks, supervised and unsupervised learning, and real-world ML workflows.',
        learningOutcomes: ['Understand AI fundamentals', 'Build ML models', 'Work with neural networks'],
        totalLessons: 6,
        duration: '40 hours'
      },
      {
        title: 'Java Programming',
        thumbnail: 'https://via.placeholder.com/280x160?text=Java',
        instructor: 'Mr. Rahul Verma',
        shortDescription: 'Intermediate Java course covering OOP and collections.',
        fullDescription: 'Comprehensive Java programming from basics to collections, multithreading, and advanced OOP concepts.',
        learningOutcomes: ['Master OOP in Java', 'Collections framework', 'Concurrency'],
        totalLessons: 6,
        duration: '48 hours'
      },
      {
        title: 'Python for Beginners',
        thumbnail: 'https://via.placeholder.com/280x160?text=Python',
        instructor: 'Ms. Sneha Patel',
        shortDescription: 'Beginner-friendly Python programming.',
        fullDescription: 'Start coding with Python, covering syntax, data types, functions, and simple automation projects.',
        learningOutcomes: ['Python syntax', 'Data structures', 'Write simple scripts'],
        totalLessons: 6,
        duration: '46 hours'
      },
      {
        title: 'Data Science Essentials',
        thumbnail: 'https://via.placeholder.com/280x160?text=Data+Science',
        instructor: 'Dr. Priya Nair',
        shortDescription: 'Advanced data science techniques and analytics.',
        fullDescription: 'Explore statistics, data processing, visualization, and machine learning for data science applications.',
        learningOutcomes: ['Data analysis', 'Statistical methods', 'ML for data science'],
        totalLessons: 6,
        duration: '41 hours'
      }
    ];

    const sampleVideos = [
      // AI & ML videos (6 lessons)
      ['https://www.youtube.com/embed/aircAruvnKk', 'https://www.youtube.com/embed/OzDG0VOWsKA', 'https://www.youtube.com/embed/JL0fm5DNVMU', 'https://www.youtube.com/embed/KeJINHsIiWM', 'https://www.youtube.com/embed/9f6qqS1VQE0', 'https://www.youtube.com/embed/ZoIIZ0K5gH0'],
      // Java videos (6 lessons)
      ['https://www.youtube.com/embed/eIrMbAQSU34', 'https://www.youtube.com/embed/jFXiNvfm-hE', 'https://www.youtube.com/embed/ntLkmAI-Neg', 'https://www.youtube.com/embed/xk4_1vDrzzo', 'https://www.youtube.com/embed/I0ZskLRkSpQ', 'https://www.youtube.com/embed/vfnGQNuKwUQ'],
      // Python videos (6 lessons)
      ['https://www.youtube.com/embed/rfscVS0vtik', 'https://www.youtube.com/embed/kqtD5dpn9C0', 'https://www.youtube.com/embed/8DvO9APVvuY', 'https://www.youtube.com/embed/pFvSLVy1Rs8', 'https://www.youtube.com/embed/OYJy_edIiMI', 'https://www.youtube.com/embed/qqvKiT5S9cY'],
      // Data Science videos (6 lessons)
      ['https://www.youtube.com/embed/32udqal_lyQ', 'https://www.youtube.com/embed/j1baWcMupWs', 'https://www.youtube.com/embed/_vQ2PJ94Mrs', 'https://www.youtube.com/embed/W7GgLcNjucQ', 'https://www.youtube.com/embed/qz0K3dBMark', 'https://www.youtube.com/embed/tKa0zDDDolc']
    ];

    let courseCount = 0;
    for (let courseIdx = 0; courseIdx < courseData.length; courseIdx++) {
      const c = courseData[courseIdx];
      const course = new Course(c);
      await course.save();

      for (let i = 0; i < c.totalLessons; i++) {
        const lesson = new Lesson({
          course: course._id,
          title: `${c.learningOutcomes[i % c.learningOutcomes.length]}`,
          order: i + 1,
          videoUrl: sampleVideos[courseIdx][i]
        });
        await lesson.save();
        course.lessons.push(lesson._id);
      }

      await course.save();
      courseCount++;
      console.log(`✓ Seeded: ${c.title} (${c.totalLessons} lessons with real YouTube videos)`);
    }

    console.log(`\n✓ Seed complete! Added ${courseCount} courses`);
    process.exit(0);
  } catch (err) {
    console.error('✗ Seed error:', err.message);
    process.exit(1);
  }
}

run();