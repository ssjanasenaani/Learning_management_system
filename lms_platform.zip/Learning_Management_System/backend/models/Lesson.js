const mongoose = require('mongoose');

const LessonSchema = new mongoose.Schema({
  course: { type: mongoose.Schema.Types.ObjectId, ref: 'Course' },
  title: { type: String, required: true },
  order: { type: Number, required: true },
  videoUrl: { type: String, required: true }
});

module.exports = mongoose.model('Lesson', LessonSchema);
