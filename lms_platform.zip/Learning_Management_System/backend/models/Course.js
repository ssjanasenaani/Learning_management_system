const mongoose = require('mongoose');

const CourseSchema = new mongoose.Schema({
  title: { type: String, required: true },
  thumbnail: String,
  instructor: String,
  shortDescription: String,
  fullDescription: String,
  learningOutcomes: [String],
  totalLessons: Number,
  duration: String,
  lessons: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Lesson' }]
});

module.exports = mongoose.model('Course', CourseSchema);
