const express = require('express');
const router = express.Router();
const Course = require('../models/Course');

// GET all courses
router.get('/', async (req, res) => {
  try {
    const courses = await Course.find().select('-lessons');
    res.json(courses);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// create a new course
router.post('/', async (req, res) => {
  try {
    const course = new Course(req.body);
    await course.save();
    res.status(201).json(course);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET course details by id (populate lessons)
router.get('/:id', async (req, res) => {
  try {
    const course = await Course.findById(req.params.id).populate('lessons');
    if (!course) return res.status(404).json({ message: 'Course not found' });
    res.json(course);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// add a lesson to a course
router.post('/:id/lessons', async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) return res.status(404).json({ message: 'Course not found' });
    const Lesson = require('../models/Lesson');
    const lesson = new Lesson({ ...req.body, course: course._id });
    await lesson.save();
    course.lessons.push(lesson._id);
    course.totalLessons = course.lessons.length;
    await course.save();
    res.status(201).json(lesson);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
