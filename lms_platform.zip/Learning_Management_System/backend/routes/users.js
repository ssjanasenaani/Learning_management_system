const express = require('express');
const router = express.Router();
const User = require('../models/User');

// create new user (for demo)
router.post('/', async (req, res) => {
  try {
    const newUser = new User(req.body);
    await newUser.save();
    res.json(newUser);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// enroll in a course
router.post('/:id/enroll', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    const { courseId } = req.body;
    if (!courseId) return res.status(400).json({ message: 'courseId required' });
    
    const courseIdStr = courseId.toString();
    const isEnrolled = user.enrolledCourses.some(id => id.toString() === courseIdStr);
    
    if (!isEnrolled) {
      user.enrolledCourses.push(courseId);
      await user.save();
    }
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
