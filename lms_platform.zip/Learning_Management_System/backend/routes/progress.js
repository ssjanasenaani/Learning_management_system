const express = require('express');
const router = express.Router();
const Progress = require('../models/Progress');

// record a completed lesson
router.post('/', async (req, res) => {
  const { userId, courseId, lessonId } = req.body;
  try {
    // avoid duplicate entries
    let record = await Progress.findOne({ user: userId, course: courseId, lesson: lessonId });
    if (!record) {
      record = new Progress({ user: userId, course: courseId, lesson: lessonId });
      await record.save();
    }
    res.json(record);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// get progress for a user/course
router.get('/', async (req, res) => {
  const { userId, courseId } = req.query;
  try {
    const records = await Progress.find({ user: userId, course: courseId });
    res.json(records);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
