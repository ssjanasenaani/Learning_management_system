const express = require('express');
const router = express.Router();
const Lesson = require('../models/Lesson');

// GET lesson by id
router.get('/:id', async (req, res) => {
  try {
    const lesson = await Lesson.findById(req.params.id);
    if (!lesson) return res.status(404).json({ message: 'Lesson not found' });
    res.json(lesson);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// SEARCH lessons by title (case‑insensitive substring)
router.get('/search', async (req, res) => {
  try {
    const { title } = req.query;
    if (!title) return res.status(400).json({ message: 'title query required' });
    const regex = new RegExp(title, 'i');
    const lessons = await Lesson.find({ title: regex }).populate('course');
    res.json(lessons);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
