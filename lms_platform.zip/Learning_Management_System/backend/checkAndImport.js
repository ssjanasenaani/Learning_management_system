// Quick verification and import script
const mongoose = require('mongoose');
const XLSX = require('xlsx');
require('dotenv').config();
const Course = require('./models/Course');
const Lesson = require('./models/Lesson');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/lms';

async function main() {
  try {
    console.log('Connecting to MongoDB...');
    await mongoose.connect(MONGO_URI);
    console.log('✓ Connected\n');

    // Check if data exists
    const courseCount = await Course.countDocuments();
    const lessonCount = await Lesson.countDocuments();
    console.log(`Current data: ${courseCount} courses, ${lessonCount} lessons\n`);

    if (lessonCount === 0 || courseCount === 0) {
      console.log('Importing from Excel...');
      
      // Read Excel
      const wb = XLSX.readFile('LMS_Courses_With_Clickable_Links (1).xlsx');
      const courseListSheet = wb.Sheets['Courses List'];
      const courseList = XLSX.utils.sheet_to_json(courseListSheet);
      
      // Clear old data
      await Course.deleteMany({});
      await Lesson.deleteMany({});
      
      let totalLessons = 0;
      
      for (const courseInfo of courseList) {
        const courseName = courseInfo['Course Name'];
        const lessonSheet = wb.Sheets[courseName];
        if (!lessonSheet) continue;
        
        const lessons = XLSX.utils.sheet_to_json(lessonSheet);
        
        // Create course
        const course = new Course({
          title: courseName,
          instructor: courseInfo['Instructor'],
          thumbnail: 'https://via.placeholder.com/280x160?text=' + encodeURIComponent(courseName),
          shortDescription: `${courseInfo['Level']} level course`,
          fullDescription: `${courseName} with ${courseInfo['Total Videos']} videos`,
          learningOutcomes: lessons.map((l, i) => l['Section Name'] || `Lesson ${i + 1}`),
          totalLessons: lessons.length,
          duration: `${Math.ceil(lessons.length * 8)} hours`
        });
        
        await course.save();
        
        // Add lessons
        for (let i = 0; i < lessons.length; i++) {
          const lessonData = lessons[i];
          const lessonTitle = lessonData['Section Name'] || `Lesson ${i + 1}`;
          
          // Extract hyperlink URL
          let youtubeUrl = '';
          const cellRef = XLSX.utils.encode_cell({ r: i + 1, c: 3 });
          if (lessonSheet[cellRef] && lessonSheet[cellRef].l && lessonSheet[cellRef].l.Rel) {
            youtubeUrl = lessonSheet[cellRef].l.Rel.Target;
          }
          
          // Convert to embed URL
          let embedUrl = youtubeUrl;
          if (youtubeUrl.includes('youtube.com/watch?v=')) {
            const id = youtubeUrl.match(/v=([a-zA-Z0-9_-]+)/)[1];
            embedUrl = `https://www.youtube.com/embed/${id}`;
          } else if (youtubeUrl.includes('youtu.be/')) {
            const id = youtubeUrl.match(/youtu\.be\/([a-zA-Z0-9_-]+)/)[1];
            embedUrl = `https://www.youtube.com/embed/${id}`;
          }
          
          const lesson = new Lesson({
            course: course._id,
            title: lessonTitle,
            order: i + 1,
            videoUrl: embedUrl || 'https://www.youtube.com/embed/dQw4w9WgXcQ'
          });
          
          await lesson.save();
          course.lessons.push(lesson._id);
          totalLessons++;
        }
        
        await course.save();
        console.log(`✓ ${courseName}: ${lessons.length} lessons`);
      }
      
      console.log(`\n✅ Import complete! ${totalLessons} lessons added`);
    } else {
      console.log('Data already imported. Checking video URLs...\n');
      const lesson = await Lesson.findOne();
      console.log('Sample lesson:');
      console.log('  Title:', lesson.title);
      console.log('  Video URL:', lesson.videoUrl);
      console.log('\n✓ Videos appear to be configured');
    }
    
    process.exit(0);
  } catch (err) {
    console.error('❌ Error:', err.message);
    process.exit(1);
  }
}

main();
