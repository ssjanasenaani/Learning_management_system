// Debugging utility to inspect database contents
const mongoose = require('mongoose');
require('dotenv').config();
const Course = require('./models/Course');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/lms';

(async () => {
  try {
    await mongoose.connect(MONGO_URI);
    const courses = await Course.find().populate('lessons');
    console.log(`\n✓ Found ${courses.length} courses:\n`);
    courses.forEach(c => {
      console.log(`  • ${c.title}`);
      console.log(`    Instructor: ${c.instructor}`);
      console.log(`    Lessons: ${c.lessons.length}\n`);
    });
    process.exit(0);
  } catch (err) {
    console.error('✗ Error:', err.message);
    process.exit(1);
  }
})();