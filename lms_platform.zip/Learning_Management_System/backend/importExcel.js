// Script to import courses and lessons from Excel file
const mongoose = require('mongoose');
const XLSX = require('xlsx');
require('dotenv').config();
const Course = require('./models/Course');
const Lesson = require('./models/Lesson');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/lms';

// Helper to extract YouTube video ID from URL or hyperlink
function extractYouTubeId(url) {
  if (!url) return null;
  
  // Pattern for youtube.com/watch?v=ID
  let match = url.match(/youtube\.com\/watch\?v=([a-zA-Z0-9_-]+)/);
  if (match) return match[1];
  
  // Pattern for youtu.be/ID
  match = url.match(/youtu\.be\/([a-zA-Z0-9_-]+)/);
  if (match) return match[1];
  
  // If it's just an ID
  if (/^[a-zA-Z0-9_-]{11}$/.test(url)) return url;
  
  return null;
}

// Helper to get embed URL
function getEmbedUrl(youtubeId) {
  if (!youtubeId) return null;
  return `https://www.youtube.com/embed/${youtubeId}`;
}

async function importFromExcel() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✓ Connected to MongoDB');

    // Clear existing data
    await Course.deleteMany({});
    await Lesson.deleteMany({});
    console.log('✓ Cleared existing data');

    // Read Excel file
    const excelFile = 'LMS_Courses_With_Clickable_Links (1).xlsx';
    const wb = XLSX.readFile(excelFile);
    console.log('✓ Excel file loaded');
    console.log('📊 Available sheets:', wb.SheetNames);

    // Get course list from first sheet
    const courseListSheet = wb.Sheets['Courses List'];
    const courseList = XLSX.utils.sheet_to_json(courseListSheet);
    console.log(`\n📚 Found ${courseList.length} courses to import\n`);

    let totalCoursesCreated = 0;
    let totalLessonsCreated = 0;

    // Process each course
    for (const courseInfo of courseList) {
      const courseName = courseInfo['Course Name'];
      const sheetName = courseName; // The course sheet has same name as course

      if (!wb.Sheets[sheetName]) {
        console.log(`⚠️  No sheet found for course: ${courseName}`);
        continue;
      }

      console.log(`\n📖 Processing course: ${courseName}`);
      const lessonSheet = wb.Sheets[sheetName];
      const lessons = XLSX.utils.sheet_to_json(lessonSheet);

      // Create course
      const course = new Course({
        title: courseInfo['Course Name'],
        instructor: courseInfo['Instructor'],
        thumbnail: 'https://via.placeholder.com/280x160?text=' + encodeURIComponent(courseName),
        shortDescription: `${courseInfo['Level']} level course with ${courseInfo['Total Sections']} sections`,
        fullDescription: `Comprehensive ${courseName} course with ${courseInfo['Total Videos']} videos across ${courseInfo['Total Sections']} sections`,
        learningOutcomes: lessons.map(l => l['Section Name'] || l['Lesson Name'] || `Section ${l['Section ID']}`),
        totalLessons: lessons.length,
        duration: `${Math.ceil((courseInfo['Total Videos'] || lessons.length * 5) * 1.5)} hours`
      });

      await course.save();
      totalCoursesCreated++;
      console.log(`  ✓ Course created: ${courseName}`);

      // Add lessons
      for (let i = 0; i < lessons.length; i++) {
        const lessonData = lessons[i];
        const lessonTitle = lessonData['Section Name'] || lessonData['Lesson Name'] || `Lesson ${i + 1}`;
        let youtubeUrl = lessonData['YouTube Link'] || lessonData['Video Link'] || lessonData['URL'] || '';

        // Extract actual URL from hyperlink cells (xlsx stores hyperlinks in cell.l.Rel.Target)
        const cellRef = XLSX.utils.encode_cell({ r: i + 1, c: 3 }); // Column D (index 3) usually has links
        if (lessonSheet[cellRef]) {
          const cell = lessonSheet[cellRef];
          if (cell.l && cell.l.Rel && cell.l.Rel.Target) {
            youtubeUrl = cell.l.Rel.Target; // Extract hyperlink URL
          }
        }

        const youtubeId = extractYouTubeId(youtubeUrl);
        const embedUrl = youtubeId ? getEmbedUrl(youtubeId) : youtubeUrl;

        const lesson = new Lesson({
          course: course._id,
          title: lessonTitle,
          order: i + 1,
          videoUrl: embedUrl || 'https://www.youtube.com/embed/dQw4w9WgXcQ' // fallback video
        });

        await lesson.save();
        course.lessons.push(lesson._id);
        totalLessonsCreated++;
        console.log(`    ✓ Lesson ${i + 1}: ${lessonTitle}`);
      }

      await course.save();
    }

    console.log(`\n✅ Import complete!`);
    console.log(`   📚 Courses created: ${totalCoursesCreated}`);
    console.log(`   📹 Lessons created: ${totalLessonsCreated}`);
    process.exit(0);
  } catch (err) {
    console.error('❌ Error:', err.message);
    process.exit(1);
  }
}

importFromExcel();
