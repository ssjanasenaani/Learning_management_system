require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

app.use(cors());
app.use(bodyParser.json());

// serve frontend static files
app.use(express.static(path.join(__dirname, '../frontend')));

// Connect to MongoDB
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/lms';
mongoose
  .connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('✓ MongoDB connected'))
  .catch((err) => console.error('✗ MongoDB error:', err.message));

// Load all models FIRST to register schemas
require('./models/User');
require('./models/Lesson');
require('./models/Course');
require('./models/Progress');

// import routes
const coursesRouter = require('./routes/courses');
const lessonsRouter = require('./routes/lessons');
const progressRouter = require('./routes/progress');
const usersRouter = require('./routes/users');

// Simple route
app.get('/', (req, res) => {
  res.send('LMS backend running');
});

// mount routes
app.use('/api/courses', coursesRouter);
app.use('/api/lessons', lessonsRouter);
app.use('/api/progress', progressRouter);
app.use('/api/users', usersRouter);

// fallback to index.html for any other requests (client-side routing)
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✓ Server running on http://localhost:${PORT}`));