const apiBase = 'http://localhost:5000/api';
const appEl = document.getElementById('app');
// Helper to convert various YouTube URL formats to embed URL
function getYouTubeEmbedUrl(url) {
  if (!url) return '';
  
  // Already an embed URL
  if (url.includes('youtube.com/embed/')) return url;
  
  // youtube.com/watch?v=ID format
  let match = url.match(/(?:youtube.com\/watch\?v=|youtu.be\/)([a-zA-Z0-9_-]+)/);
  if (match) return `https://www.youtube.com/embed/${match[1]}`;
  
  // Just an ID
  if (!/[\/:.]/.test(url) && url.length >= 10) return `https://www.youtube.com/embed/${url}`;
  
  // Return as-is if already formatted
  return url;
}


// helper to prompt and create a course
async function addCourse() {
  const title = prompt('Course title:');
  if (!title) return;
  const instructor = prompt('Instructor name:');
  const thumbnail = prompt('Thumbnail URL:', 'https://via.placeholder.com/150');
  const shortDescription = prompt('Short description:');
  const fullDescription = prompt('Full description:');
  const outcomes = prompt('Outcomes (comma separated):');
  const duration = prompt('Duration:');
  const data = {
    title,
    instructor,
    thumbnail,
    shortDescription,
    fullDescription,
    learningOutcomes: outcomes ? outcomes.split(',').map(s=>s.trim()) : [],
    totalLessons: 0,
    duration
  };
  await fetch(`${apiBase}/courses`, {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(data)
  });
  showCourseList();
}

// helper to add a lesson to a course
async function addLesson(courseId, course) {
  const title = prompt('Lesson title:');
  if (!title) return;
  const videoUrl = prompt('YouTube embed URL or ID:');
  const order = course.lessons.length + 1;
  const data = { title, videoUrl, order };
  await fetch(`${apiBase}/courses/${courseId}/lessons`, {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(data)
  });
  showCourseDetail(courseId);
}

// simple hash router
window.addEventListener('hashchange', router);
window.addEventListener('load', () => {
  // create a dummy user
  fetch(`${apiBase}/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'Student', email: 'student@example.com' })
  })
    .then(res => res.json())
    .then(u => { currentUser = u; router(); });
});

function router() {
  const hash = window.location.hash || '#/';
  const parts = hash.slice(2).split('/');
  if (parts[0] === '') {
    showCourseList();
  } else if (parts[0] === 'course' && parts[1]) {
    showCourseDetail(parts[1]);
  } else if (parts[0] === 'learn' && parts[1]) {
    // if lesson id provided, show that lesson
    if (parts[2]) {
      showLearningPage(parts[1], parts[2]);
    } else {
      // otherwise resume from last progress or first lesson
      resumeLesson(parts[1]);
    }
  } else {
    appEl.innerHTML = '<p>Page not found</p>';
  }
}

async function showCourseList() {
  const res = await fetch(`${apiBase}/courses`);
  const courses = await res.json();
  appEl.innerHTML = `
    <div class="search-bar">
      <input id="lessonSearch" placeholder="Search lesson title..." />
      <button id="searchBtn">Search</button>
    </div>
    <div><button id="addCourseBtn">Add Course</button></div>
    <div id="searchResults"></div>
    <div class="course-list"></div>
  `;
  document.getElementById('addCourseBtn').onclick = addCourse;
  document.getElementById('searchBtn').onclick = async () => {
    const q = document.getElementById('lessonSearch').value.trim();
    if (!q) return;
    const resp = await fetch(`${apiBase}/lessons/search?title=${encodeURIComponent(q)}`);
    const lessons = await resp.json();
    showSearchResults(lessons, q);
  };
  const container = appEl.querySelector('.course-list');
  courses.forEach(c => {
    const card = document.createElement('div');
    card.className = 'course-card';
    card.innerHTML = `
      <img src="${c.thumbnail}" alt="${c.title}" />
      <h3>${c.title}</h3>
      <p>Instructor: ${c.instructor}</p>
      <p>${c.shortDescription}</p>
      <button onclick="location.hash='#/course/${c._id}'">View</button>
    `;
    container.appendChild(card);
  });
}

async function showCourseDetail(courseId) {
  const res = await fetch(`${apiBase}/courses/${courseId}`);
  const course = await res.json();
  appEl.innerHTML = '<div class="course-detail"></div>';
  const container = appEl.querySelector('.course-detail');
  container.innerHTML = `
    <h2>${course.title}</h2>
    <img src="${course.thumbnail}" alt="${course.title}" />
    <p>${course.fullDescription}</p>
    <p><strong>Outcomes:</strong> ${course.learningOutcomes.join(', ')}</p>
    <p><strong>Total Lessons:</strong> ${course.totalLessons}</p>
    <p><strong>Duration:</strong> ${course.duration}</p>
    <button id="enrollBtn">Enroll</button>
    <button id="addLessonBtn">Add Lesson</button>
  `;
  document.getElementById('addLessonBtn').onclick = () => addLesson(course._id, course);
  document.getElementById('enrollBtn').addEventListener('click', async () => {
    try {
      // Enroll the user
      const enrollRes = await fetch(`${apiBase}/users/${currentUser._id}/enroll`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ courseId })
      });
      if (!enrollRes.ok) throw new Error('Enrollment failed');
      
      // Fetch fresh course data with populated lessons
      const freshCourse = await fetch(`${apiBase}/courses/${courseId}`).then(r => r.json());
      
      // Find first lesson
      if (!freshCourse.lessons || freshCourse.lessons.length === 0) {
        alert('This course has no lessons yet. Please add lessons first.');
        return;
      }
      
      const firstLesson = freshCourse.lessons.sort((a, b) => a.order - b.order)[0];
      if (!firstLesson || !firstLesson._id) {
        alert('Error: Could not find lesson ID. Please try again.');
        return;
      }
      
      location.hash = `#/learn/${courseId}/${firstLesson._id}`;
    } catch (err) {
      console.error('Enrollment error:', err);
      alert('Enrollment failed: ' + err.message);
    }
  });
}

// try to resume learning from last completed lesson or start
async function resumeLesson(courseId) {
  const courseRes = await fetch(`${apiBase}/courses/${courseId}`);
  const course = await courseRes.json();
  const progRes = await fetch(`${apiBase}/progress?userId=${currentUser._id}&courseId=${courseId}`);
  const records = await progRes.json();
  const completed = records.map(r => r.lesson);
  const sorted = course.lessons.sort((a,b)=>a.order-b.order);
  let targetLesson = sorted[0];
  if (completed.length) {
    // find last completed by order
    const lastCompleted = sorted.filter(l => completed.includes(l._id)).pop();
    // if not last one, go to next
    const idx = sorted.findIndex(l => l._id === lastCompleted._id);
    if (idx < sorted.length - 1) targetLesson = sorted[idx + 1];
    else targetLesson = lastCompleted; // fully completed
  }
  location.hash = `#/learn/${courseId}/${targetLesson._id}`;
}

// display results from a lesson search
function showSearchResults(lessons, query) {
  const container = document.getElementById('searchResults');
  if (!container) return;
  if (!lessons || lessons.length === 0) {
    container.innerHTML = `<p style="margin:1rem 0;color:#ffdddd;">No lessons found for \"${query}\"</p>`;
    return;
  }
  if (lessons.length === 1) {
    const l = lessons[0];
    const courseId = l.course._id || l.course;
    location.hash = `#/learn/${courseId}/${l._id}`;
    return;
  }
  const items = lessons.map(l => {
    const courseId = l.course._id || l.course;
    return `<li><a href="#/learn/${courseId}/${l._id}" style="color:#667eea;">${l.title}</a></li>`;
  }).join('');
  container.innerHTML = `<p style="margin:1rem 0;">Found ${lessons.length} lessons for \"${query}\":</p><ul>${items}</ul>`;
}

async function showLearningPage(courseId, lessonId) {
  try {
    const courseRes = await fetch(`${apiBase}/courses/${courseId}`);
    if (!courseRes.ok) throw new Error('Failed to fetch course');
    const course = await courseRes.json();
    
    const lessonRes = await fetch(`${apiBase}/lessons/${lessonId}`);
    if (!lessonRes.ok) throw new Error('Failed to fetch lesson');
    const lesson = await lessonRes.json();

    // calculate progress
    const progRes = await fetch(`${apiBase}/progress?userId=${currentUser._id}&courseId=${courseId}`);
    const records = progRes.ok ? await progRes.json() : [];
    const completed = [...new Set(records.map(r => r.lesson))];
    let progressPercent = (completed.length / course.lessons.length) * 100;

    // Normalize YouTube URL
    const embedUrl = getYouTubeEmbedUrl(lesson.videoUrl);

    appEl.innerHTML = `
      <div class="learning-container">
        <div class="video-player">
          <div style="position:relative; width:100%; padding-bottom:56.25%; margin-bottom:1rem;">
            <iframe 
              style="position:absolute; top:0; left:0; width:100%; height:100%; border-radius:8px;"
              src="${embedUrl}" 
              title="${lesson.title}"
              frameborder="0" 
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
              allowFullscreen>
            </iframe>
          </div>
          <h3 style="margin-bottom:1rem; color:#667eea;">${lesson.title}</h3>
          <div class="progress-info">Progress: ${progressPercent.toFixed(0)}%</div>
          <div class="progress-bar"><div class="progress-bar-inner" style="width:${progressPercent}%"></div></div>
          <div class="navigation-buttons">
            <button id="prevBtn" ${0 === 0 ? 'disabled' : ''}>Previous</button>
            <button id="nextBtn">Next</button>
          </div>
        </div>
        <div class="lesson-sidebar">
          <h4 style="margin-bottom:1rem; color:#667eea;">Lessons</h4>
          <ol></ol>
        </div>
      </div>
    `;

    const ol = appEl.querySelector('.lesson-sidebar ol');
    const sorted = course.lessons.sort((a, b) => a.order - b.order);
    sorted.forEach((l, idx) => {
      const li = document.createElement('li');
      li.textContent = `${l.order}. ${l.title}`;
      if (l._id === lessonId) {
        li.style.fontWeight = 'bold';
        li.style.color = '#667eea';
      }
      if (completed.includes(l._id)) {
        li.classList.add('completed');
      }
      li.onclick = () => {
        location.hash = `#/learn/${courseId}/${l._id}`;
      };
      ol.appendChild(li);
    });

    // mark this lesson as completed
    if (!completed.includes(lessonId)) {
      const progressRes = await fetch(`${apiBase}/progress`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser._id, courseId, lessonId })
      });
      if (progressRes.ok) {
        // update progress UI after recording
        const newCompleted = [...new Set([...completed, lessonId])];
        progressPercent = (newCompleted.length / course.lessons.length) * 100;
        const progInfo = appEl.querySelector('.progress-info');
        if (progInfo) progInfo.textContent = `Progress: ${progressPercent.toFixed(0)}%`;
        const bar = appEl.querySelector('.progress-bar-inner');
        if (bar) bar.style.width = `${progressPercent}%`;
        // mark list item
        const listItems = appEl.querySelectorAll('.lesson-sidebar li');
        listItems.forEach(li => {
          const lessonTitle = li.textContent.substring(li.textContent.indexOf('.') + 2);
          const matchingLesson = sorted.find(l => l.title === lessonTitle);
          if (matchingLesson && newCompleted.includes(matchingLesson._id)) {
            li.classList.add('completed');
          }
        });
      }
    }

    const idx = sorted.findIndex(l => l._id === lessonId);
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    
    if (idx > 0) {
      prevBtn.disabled = false;
      prevBtn.onclick = () => {
        location.hash = `#/learn/${courseId}/${sorted[idx - 1]._id}`;
      };
    } else {
      prevBtn.disabled = true;
    }
    
    if (idx < sorted.length - 1) {
      nextBtn.disabled = false;
      nextBtn.onclick = () => {
        location.hash = `#/learn/${courseId}/${sorted[idx + 1]._id}`;
      };
    } else {
      nextBtn.disabled = true;
    }
  } catch (err) {
    console.error('Learning page error:', err);
    appEl.innerHTML = `<div style="padding:2rem; text-align:center; color:red;"><h2>Error Loading Lesson</h2><p>${err.message}</p><button onclick="location.hash='#/'">Back to Courses</button></div>`;
  }
}
